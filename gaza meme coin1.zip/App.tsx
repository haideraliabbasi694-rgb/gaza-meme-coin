import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Shield,
  HeartHandshake,
  Coins,
  Sparkles,
  ExternalLink,
  Wallet,
  FileText,
  LineChart,
  BadgeCheck,
  HandCoins,
  Calculator,
  TrendingUp,
  Crown,
} from "lucide-react";
import GazaLogo from "./assets/gaza-logo.svg";

const Section = ({
  id,
  title,
  subtitle,
  children,
}: {
  id?: string;
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
}) => (
  <section id={id} className="w-full max-w-6xl mx-auto px-4 py-16">
    <motion.h2
      initial={{ opacity: 0, y: 8 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="text-3xl sm:text-4xl font-bold tracking-tight flex items-center gap-3"
    >
      <img src={GazaLogo} alt="Gaza Meme Coin" className="w-8 h-8" />
      {title}
    </motion.h2>
    {subtitle && (
      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="mt-3 text-lg text-zinc-600"
      >
        {subtitle}
      </motion.p>
    )}
    <div className="mt-8">{children}</div>
  </section>
);

const Card = ({ children }: { children: React.ReactNode }) => (
  <div className="rounded-2xl shadow-sm border border-zinc-200 bg-white p-6">
    {children}
  </div>
);

function ProfitCalculator() {
  const [buyPrice, setBuyPrice] = useState(0);
  const [sellPrice, setSellPrice] = useState(0);
  const [amount, setAmount] = useState(0);

  const profit = (sellPrice - buyPrice) * amount;
  const suggestedDonation = profit > 0 ? profit * 0.3 : 0;

  return (
    <Card>
      <div className="flex items-start gap-3">
        <Calculator className="w-6 h-6" />
        <div className="flex-1">
          <h3 className="font-semibold">Profit calculator</h3>
          <p className="text-sm text-zinc-600 mt-1">
            Estimate your trade gains and see the suggested 30% donation amount.
          </p>

          <div className="mt-4 grid gap-3">
            <input
              type="number"
              placeholder="Buy price ($)"
              value={buyPrice}
              onChange={(e) =>
                setBuyPrice(parseFloat(e.target.value) || 0)
              }
              className="border rounded-lg px-3 py-2 text-sm"
            />
            <input
              type="number"
              placeholder="Sell price ($)"
              value={sellPrice}
              onChange={(e) =>
                setSellPrice(parseFloat(e.target.value) || 0)
              }
              className="border rounded-lg px-3 py-2 text-sm"
            />
            <input
              type="number"
              placeholder="Amount (tokens)"
              value={amount}
              onChange={(e) =>
                setAmount(parseFloat(e.target.value) || 0)
              }
              className="border rounded-lg px-3 py-2 text-sm"
            />
          </div>

          {profit !== 0 && (
            <div className="mt-4 text-sm">
              <p>
                Your profit:{" "}
                <span className="font-semibold">${profit.toFixed(2)}</span>
              </p>
              {profit > 0 ? (
                <>
                  <p>
                    Suggested 30% donation:{" "}
                    <span className="font-semibold text-emerald-600">
                      ${suggestedDonation.toFixed(2)}
                    </span>
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <a
                      href="https://www.palestinercs.org/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 bg-emerald-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                    >
                      Donate PRCS <ExternalLink className="w-3 h-3" />
                    </a>
                    <a
                      href="https://www.icrc.org/en/donate"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 bg-emerald-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                    >
                      Donate ICRC <ExternalLink className="w-3 h-3" />
                    </a>
                    <a
                      href="https://donate.wfp.org/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 bg-emerald-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                    >
                      Donate WFP <ExternalLink className="w-3 h-3" />
                    </a>
                    <a
                      href="https://donate.doctorswithoutborders.org/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 bg-emerald-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                    >
                      Donate MSF <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </>
              ) : (
                <p className="text-zinc-500">
                  No profit, no donation suggested.
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}

function DonationTracker() {
  const [donations, setDonations] = useState<{ name: string; amount: number }[]>([
    { name: "Anon1", amount: 150 },
    { name: "Anon2", amount: 200 },
    { name: "Anon3", amount: 50 },
  ]);
  const total = donations.reduce((a, b) => a + b.amount, 0);

  const addDonation = (name: string, amount: number) =>
    setDonations([...donations, { name, amount }]);
  const topDonors = [...donations]
    .sort((a, b) => b.amount - a.amount)
    .slice(0, 5);

  return (
    <Card>
      <div className="flex items-start gap-3">
        <TrendingUp className="w-6 h-6" />
        <div className="flex-1">
          <h3 className="font-semibold">Community donation tracker</h3>
          <p className="text-sm text-zinc-600 mt-1">
            Track the impact of our community. Submit your donation to add it to
            the live total. You may stay anonymous or display your name.
          </p>

          <div className="mt-4 text-sm">
            <p>
              Total reported donations:{" "}
              <span className="font-bold text-emerald-600">
                ${total.toFixed(2)}
              </span>
            </p>
            <div className="mt-3 flex flex-col gap-2">
              <input
                type="text"
                placeholder="Your name (or leave blank for Anon)"
                className="border rounded-lg px-3 py-2 text-sm"
                id="donorNameInput"
              />
              <div className="flex gap-2">
                <input
                  type="number"
                  placeholder="Enter your donation ($)"
                  className="border rounded-lg px-3 py-2 text-sm flex-1"
                  id="donationInput"
                />
                <button
                  onClick={() => {
                    const nameInput = document.getElementById(
                      "donorNameInput"
                    ) as HTMLInputElement;
                    const input = document.getElementById(
                      "donationInput"
                    ) as HTMLInputElement;
                    const val = parseFloat(input.value);
                    const name = nameInput.value.trim() || "Anonymous";
                    if (!isNaN(val) && val > 0) addDonation(name, val);
                    input.value = "";
                    nameInput.value = "";
                  }}
                  className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-semibold"
                >
                  Submit
                </button>
              </div>
            </div>
          </div>

          {topDonors.length > 0 && (
            <div className="mt-6">
              <h4 className="font-semibold flex items-center gap-2">
                <Crown className="w-4 h-4 text-yellow-500" /> Top contributors
              </h4>
              <ul className="mt-2 space-y-1 text-sm">
                {topDonors.map((d, i) => (
                  <li
                    key={i}
                    className="flex justify-between border-b border-zinc-100 py-1"
                  >
                    <span>{d.name}</span>
                    <span className="font-medium">${d.amount.toFixed(2)}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}

export default function GazaMemeCoin() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-50 via-white to-zinc-50 text-zinc-900">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur bg-white/70 border-b border-zinc-200">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <a href="#top" className="font-extrabold text-xl tracking-tight flex items-center gap-2">
            <img src={GazaLogo} alt="GAZA Meme Coin" className="w-8 h-8" />
            GAZA • MEME
          </a>
          <nav className="hidden sm:flex gap-6 text-sm">
            <a href="#how" className="hover:opacity-80">How it works</a>
            <a href="#ngos" className="hover:opacity-80">NGOs</a>
            <a href="#ethics" className="hover:opacity-80">Ethics</a>
            <a href="#faq" className="hover:opacity-80">FAQ</a>
          </nav>
          <div className="flex gap-2">
            <a href="#buy" className="px-4 py-2 rounded-xl bg-black text-white text-sm font-semibold shadow-sm">Buy (soon)</a>
            <a href="#donate" className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-sm font-semibold shadow-sm">Donate</a>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section id="top" className="relative overflow-hidden">
        <div className="max-w-6xl mx-auto px-4 pt-20 pb-16 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <motion.h1
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl sm:text-6xl font-black tracking-tight leading-tight flex items-center gap-3"
            >
              <img src={GazaLogo} alt="Gaza Logo" className="w-12 h-12" />
              A meme with a mission.
            </motion.h1>
            <p className="mt-4 text-lg text-zinc-600">
              GAZA • MEME ($GAZA) is a transparent, community-driven token with
              one goal: raise funds for vetted humanitarian relief serving
              civilians in Gaza. No promises, no hype—just receipts.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a
                href="#donate"
                className="px-5 py-3 rounded-2xl bg-emerald-600 text-white font-semibold shadow"
              >
                Donate now
              </a>
              <a
                href="#how"
                className="px-5 py-3 rounded-2xl bg-white border border-zinc-200 font-semibold shadow-sm"
              >
                View how it works
              </a>
            </div>
            <div className="mt-6 text-xs text-zinc-500">
              <p>
                Disclaimer: $GAZA is a memetic community token with no expected
                profit or utility. Do not buy expecting returns. Donations are
                routed directly to independent NGOs; token buys are separate and
                not tax-deductible.
              </p>
            </div>
          </div>
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative"
          >
            <div className="aspect-square rounded-3xl bg-gradient-to-br from-emerald-500/20 via-teal-400/10 to-sky-400/10 border border-emerald-400/20 shadow-inner" />
            <div className="absolute inset-0 grid place-items-center pointer-events-none">
              <Sparkles className="w-24 h-24 opacity-30" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* How It Works */}
      <Section
        id="how"
        title="How it works"
        subtitle="Simple, auditable flows—no hidden taxes or shady wallets."
      >
        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <div className="flex items-start gap-3">
              <Coins className="w-6 h-6" />
              <div>
                <h3 className="font-semibold">Fair launch</h3>
                <p className="text-sm text-zinc-600 mt-1">
                  0% transfer taxes. Fixed supply. Liquidity locked. Contract
                  renounced after checks. Community first.
                </p>
              </div>
            </div>
          </Card>
          <Card>
            <div className="flex items-start gap-3">
              <HeartHandshake className="w-6 h-6" />
              <div>
                <h3 className="font-semibold">Donation treasury</h3>
                <p className="text-sm text-zinc-600 mt-1">
                  A multisig wallet holds the charity allocation. Periodic
                  on-chain grants go to vetted NGOs. Every disbursement is
                  posted with tx links.
                </p>
              </div>
            </div>
          </Card>
          <Card>
            <div className="flex items-start gap-3">
              <Shield className="w-6 h-6" />
              <div>
                <h3 className="font-semibold">Compliance & safety</h3>
                <p className="text-sm text-zinc-600 mt-1">
                  We only donate to recognized humanitarian organisations via
                  compliant rails. No funds to sanctioned entities. KYC for
                  signers.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </Section>

      {/* NGO Info */}
      <Section
        id="ngos"
        title="Who we support"
        subtitle="Vetted humanitarian NGOs helping civilians in Gaza."
      >
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <h3 className="font-semibold">Palestine Red Crescent Society (PRCS)</h3>
            <p className="text-sm text-zinc-600 mt-1">
              PRCS provides emergency medical services, ambulances, and
              community health programs for Palestinians affected by conflict.
            </p>
          </Card>
          <Card>
            <h3 className="font-semibold">International Committee of the Red Cross (ICRC)</h3>
            <p className="text-sm text-zinc-600 mt-1">
              The ICRC delivers medical aid, supports hospitals, and ensures
              compliance with humanitarian law in Gaza.
            </p>
          </Card>
          <Card>
            <h3 className="font-semibold">World Food Programme (WFP)</h3>
            <p className="text-sm text-zinc-600 mt-1">
              WFP provides food relief to displaced families and supports food
              security during crises.
            </p>
          </Card>
          <Card>
            <h3 className="font-semibold">Doctors Without Borders (MSF)</h3>
            <p className="text-sm text-zinc-600 mt-1">
              MSF offers critical medical care, surgery, and trauma treatment
              to civilians in Gaza under fire.
            </p>
          </Card>
        </div>
      </Section>

      {/* Ethics */}
      <Section
        id="ethics"
        title="Ethical trading"
        subtitle="Profits can help save lives—community traders are encouraged to share."
      >
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <div className="flex items-start gap-3">
              <HandCoins className="w-6 h-6" />
              <div>
                <h3 className="font-semibold">30% give-back</h3>
                <p className="text-sm text-zinc-600 mt-1">
                  We kindly ask everyone who trades $GAZA and makes a profit to
                  donate at least{" "}
                  <span className="font-semibold">30% of their profit</span> to
                  the humanitarian organisations listed above. This is
                  voluntary, but it turns trading into tangible relief.
                </p>
              </div>
            </div>
          </Card>
          <Card>
            <div className="flex items-start gap-3">
              <HeartHandshake className="w-6 h-6" />
              <div>
                <h3 className="font-semibold">Direct links</h3>
                <p className="text-sm text-zinc-600 mt-1">
                  Use the donation buttons on this site to route funds straight
                  to PRCS, ICRC, WFP, or MSF. We
